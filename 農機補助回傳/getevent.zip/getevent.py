
	@CASE00035_EVENT_BLUEPRINT.get("/getevent/<int:id>")
	def getevent(id):
		header=request.headers.get("Authorization")
		if header:
			token=chash(header.split(" ")[1],"decode")
			if token!=None:
				tokenrow=query(SETTING["dbname"],"SELECT*FROM `token` WHERE `token`=%s",[token],SETTING["dbsetting"])
				if tokenrow:
					userid=tokenrow[0]["userid"]
					row=query(SETTING["dbname"],"SELECT*FROM `event` WHERE `id`=%s AND `deletetime` IS NULL",[id],SETTING["dbsetting"])
					if row:
						userrow=query(SETTING["dbname"],"SELECT*FROM `user` WHERE `id`=%s",[userid],SETTING["dbsetting"])
						if userrow:
							if userid==row[0]["userid"] or 4<=int(userrow[0]["permission"]):
								eventuserrow=query(SETTING["dbname"],"SELECT*FROM `user` WHERE `id`=%s",[row[0]["userid"]],SETTING["dbsetting"])
								session=requests.Session()
								requestcallsignin=session.get(f"http://apitest.18gps.net/GetDateServices.asmx/loginSystem?LoginName={eventuserrow[0]['gpsno']}&LoginPassword=123456&LoginType=USER&language=cn&ISMD5=0&timeZone=+08&apply=APP&loginUrl=http://vipopenapi.18gps.net/",verify=False)
								signinrequestdata=json.loads(requestcallsignin.text)
								if signinrequestdata["success"]:
									# !!! FIX: 資料有可能會有超1000筆之情況，因此需要判斷是否為超1000筆的資料並且繼續接 !!!
									mds=signinrequestdata["mds"]
									requestcallflight=session.get(f"http://apitest.18gps.net//GetDateServices.asmx/GetDate?method=getHistoryMByMUtcNew&mds={mds}&playLBS=true&macid={eventuserrow[0]['gpsno']}&mapType=GOOGLECN&from={row[0]['starttime']}&to={row[0]['endtime']}",verify=False)
									#requestcallflight=session.get(f"http://apitest.18gps.net//GetDateServices.asmx/GetDate?method=getHistoryMByMUtcNew&mds={mds}&playLBS=true&macid={userrow['gpsno']}&mapType=GOOGLECN&from={starttime}&to={endtime}",verify=False)
									flightrequestdata=json.loads(requestcallflight.text)
									if flightrequestdata["success"]:
										kml=flightrequestdata["data"][0]["Point"]
									else:
										return jsonify({
											"success": False,
											"data": "ERROR_ajax_request_error_request2.7"
										}),500
								else:
									return jsonify({
										"success": False,
										"data": "ERROR_ajax_request_error_request1.1"
									}),500

								return jsonify({
									"success": True,
									"data": {
										"id": row[0]["id"],
										"user": userrow,
										"oemedfile": row[0]["oemedfile"],
										"droneno": row[0]["droneno"],
										"implementdate": row[0]["implementdate"],
										"cropname": row[0]["cropname"],
										"sprayarea": row[0]["sprayarea"],
										"oemed": row[0]["oemed"],
										"cert": row[0]["cert"],
										"kml": kml,
										"usebindingmaterial": row[0]["usebindingmaterial"],
										"starttime": row[0]["starttime"],
										"endtime": row[0]["endtime"],
										"uploaded": row[0]["uploaded"],
										"createtime": row[0]["createtime"],
										"updatetime": row[0]["updatetime"]
									}
								}),200
							else:
								return jsonify({
									"success": False,
									"data": "ERROR_no_permission"
								}),403
						else:
							return jsonify({
								"success": False,
								"data": "ERROR_token_error"
							}),401
					else:
						return jsonify({
							"success": False,
							"data": "ERROR_event_not_found"
						}),404
				else:
					return jsonify({
						"success": False,
						"data": "ERROR_token_error"
					}),401
			else:
				return jsonify({
					"success": False,
					"data": "ERROR_token_decode_error"
				}),400
		else:
			return jsonify({
				"success": False,
				"data": "ERROR_token_not_found"
			}),401